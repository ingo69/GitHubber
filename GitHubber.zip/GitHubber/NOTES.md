#  NOTES

this will be the template for the future collectionviews
it has 
1) pagination
2) cache
3) networked avatars
4) Networking




