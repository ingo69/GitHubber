//
//  GFButton.swift
//  GitHubber
//
//  Created by Ingo Ngoyama on 1/14/20.
//  Copyright © 2020 Ingo Ngoyama. All rights reserved.
//

//PURPOSE: We make a universal styler for the buttons in this app

import UIKit

class GFButton: UIButton {

//MANDATORY CLASS CODE######################################
    override init(frame: CGRect) {// mandatory class init
        super.init(frame: frame)// call on parent class (UIButton) library
        config() // we make this func below to style the button
    }
    
    
    required init?(coder: NSCoder) { //This mandatory stub is a Strbrd init stub. we use UIKit so it leave like this
        fatalError("init(coder:) has not been implemented")
    }
    
 //CUSTOM BUTTON CODE##############################################
   convenience  init(backgroundColor: UIColor, title: String){ // soft code bkgrd color and title
        self.init(frame: .zero) //we will set the width and height with autolayout when it is called
        self.backgroundColor = backgroundColor
        self.setTitle(title, for: .normal)
        
    }
    
    
    private func config(){ // style the button
        layer.cornerRadius = 10
        titleLabel?.textColor = .white
        titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)// suggested dynamic type text
        translatesAutoresizingMaskIntoConstraints = false // use autoLayout when called
    }
    
    
    func set(backgroundColor:UIColor, title:String){
        self.backgroundColor = backgroundColor
        setTitle(title, for: .normal)
    }
    
    
}
