//
//  GFRepoItemVC.swift
//  GitHubber
//
//  Created by Ingo Ngoyama on 2/8/20.
//  Copyright © 2020 Ingo Ngoyama. All rights reserved.
//

import UIKit

class GFRepoItemVC: GFItemInfoVC{
    override func viewDidLoad() {
        super.viewDidLoad()
        configureItems()
    }
    
    
    private func configureItems(){
        itemInfoViewOne.set(itemInfoType: .repos, withcount: user.publicRepos)
        itemInfoViewTwo.set(itemInfoType: .gists, withcount: user.publicGists)
        actionButton.set(backgroundColor: .systemPurple, title: "GitHub Profile")
    }
    
    
    override func actionButtonTapped() {
        delegate.didTapGitHubProfile(for: user)
    }
    
    
}













