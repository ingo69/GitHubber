//
//  GFFollowersItemVC.swift
//  GitHubber
//
//  Created by Ingo Ngoyama on 2/8/20.
//  Copyright © 2020 Ingo Ngoyama. All rights reserved.
//

import UIKit

class GFFollowerItemVC: GFItemInfoVC{
    override func viewDidLoad() {
        super.viewDidLoad()
        configureItems()
    }
    
    
    private func configureItems(){
        itemInfoViewOne.set(itemInfoType: .followers, withcount: user.followers)
        itemInfoViewTwo.set(itemInfoType: .following, withcount: user.following)
        actionButton.set(backgroundColor: .systemGreen, title: "Get Followers")
    }
    
    
    override func actionButtonTapped() {
        delegate.didTapGetFollowers(for: user)
    }
}
