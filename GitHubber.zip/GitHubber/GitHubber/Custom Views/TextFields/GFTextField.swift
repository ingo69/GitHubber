//
//  GFTextField.swift
//  GitHubber
//
//  Created by Ingo Ngoyama on 1/14/20.
//  Copyright © 2020 Ingo Ngoyama. All rights reserved.
//

import UIKit

class GFTextField: UITextField {

//MANDATORY CLASS CODE######################################
    override init(frame: CGRect) {
        super.init(frame: frame)
        config()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
//CUSTOM TEXTFIELD CODE##############################################
    private func config(){
        translatesAutoresizingMaskIntoConstraints = false //  use autolayout when called
        
        layer.cornerRadius          = 10
        layer.borderWidth           = 2
        layer.borderColor           = UIColor.systemGray4.cgColor
        
        textColor                   = .label
        tintColor                   = .label  //cursor color
        textAlignment               = .center
        font                        = UIFont.preferredFont(forTextStyle: .title2) // suggested dynamic text
        adjustsFontSizeToFitWidth   = true
        minimumFontSize             = 12
        
        backgroundColor             = .tertiarySystemBackground
        autocorrectionType          = .no
        returnKeyType               = .go // shows go instead of return
        clearButtonMode             = .whileEditing // a clear text button at end of TF
        placeholder                 =  "Enter a username"
        
    }
}
