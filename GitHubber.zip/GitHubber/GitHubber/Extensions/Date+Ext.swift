//
//  Date+Ext.swift
//  GitHubber
//
//  Created by Ingo Ngoyama on 2/9/20.
//  Copyright © 2020 Ingo Ngoyama. All rights reserved.
//

import Foundation

extension Date{
    
    func convertToMonthYearFormat()-> String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM yyyy" // refer to NSDateForematter.com
        return dateFormatter.string(from: self)
    }
    
}











