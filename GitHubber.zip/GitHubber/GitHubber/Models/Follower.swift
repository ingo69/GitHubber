//
//  Follower.swift
//  GitHubber
//
//  Created by Ingo Ngoyama on 1/20/20.
//  Copyright © 2020 Ingo Ngoyama. All rights reserved.
//

import Foundation

struct Follower: Codable, Hashable{
    var login: String
    var avatarUrl: String // we changed the snake_case to  camelCase for the key
}










